/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.chatapp;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 *
 * @author hifi
 */
public class login {
    private user registeredUser = null;

    // Username: contains underscore, max 5 characters
    public boolean checkUsername(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    // Password: at least 8 chars, includes uppercase, digit, special char
    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) return false;
        boolean hasUpper = false, hasDigit = false, hasSpecial = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            else if (Character.isDigit(c)) hasDigit = true;
            else if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }
        return hasUpper && hasDigit && hasSpecial;
    }

    // Cellphone: South Africa +27 format
    public boolean checkCellphone(String cellphone) {
        if (cellphone == null) return false;
        return cellphone.matches("^\\+27\\d{9}$");
    }

    // Register a user
    public String registerUser(String username, String password, String cellphone) {
        if (!checkUsername(username)) {
            return "Username must contain '_' and be no more than 5 characters.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password must be 8+ characters, include uppercase, digit, and special character.";
        }
        if (!checkCellphone(cellphone)) {
            return "Cellphone number incorrectly formatted or doesn't contain international code.";
        }

        // Trim input to avoid hidden spaces
        username = username.trim();
        password = password.trim();
        cellphone = cellphone.trim();

        this.registeredUser = new user(username, password, cellphone);
        return "Registration successful.";
    }

    // Login a user
    public boolean loginUser(String username, String password) {
        if (this.registeredUser == null) return false;
        if (username == null || password == null) return false;

        // Trim to remove any accidental spaces
        username = username.trim();
        password = password.trim();

        return registeredUser.getUsername().equals(username)
                && registeredUser.getPassword().equals(password);
    }

    // Returns login feedback message
    public String returnLoginStatus(boolean loginResult, String username) {
        if (!loginResult) return "Username or password incorrect, please try again.";

        String firstName = "", lastName = "";
        if (username != null && username.contains("_")) {
            String[] parts = username.split("_", 2);
            firstName = parts[0];
            lastName = parts[1];
        } else {
            firstName = username;
        }

        return String.format("Welcome %s %s, it is great to see you again.", firstName, lastName);
    }

    public user getRegisteredUser() {
        return registeredUser;
    }
}
