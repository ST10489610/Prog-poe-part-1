/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.chatapp;

import org.junit.Before;
import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

public class MessageManagerTest {

    private MessageManager manager;

    @Before
    public void setUp() {
        manager = new MessageManager();
        manager.getMessages().clear();   // Clear loaded messages
    }

    // ---------------------------------------------------------
    @Test
    public void testAddMessageSuccess() {
        Message msg = new Message(0, "+27838968976", "+27838968976", "Hello world");
        manager.sendMessage(msg);

        assertEquals(1, manager.getMessages().size());
        assertEquals("Hello world", manager.getMessages().get(0).getContent());
    }

    // ---------------------------------------------------------
    @Test
    public void testSearchByRecipient() {
        Message m1 = new Message(0, "+27830000000", "+27831111111", "Msg1");
        Message m2 = new Message(1, "+27830000000", "+27831111111", "Msg2");
        Message m3 = new Message(2, "+27830000000", "+27832222222", "Msg3");

        manager.sendMessage(m1);
        manager.sendMessage(m2);
        manager.sendMessage(m3);

        List<Message> result = manager.searchByRecipient("+27831111111");

        assertEquals(2, result.size());
    }

    // ---------------------------------------------------------
    @Test
    public void testSearchById() {
        Message m = new Message(0, "+27838968976", "+27838968976", "Test");
        manager.sendMessage(m);

        Message found = manager.searchById(m.getId());

        assertNotNull(found);
        assertEquals(m.getId(), found.getId());
    }

    // ---------------------------------------------------------
    @Test
    public void testGetLongestMessage() {
        Message m1 = new Message(0, "+2783", "+2783", "Short");
        Message m2 = new Message(1, "+2783", "+2783", "This message is definitely longer");

        manager.sendMessage(m1);
        manager.sendMessage(m2);

        Message longest = manager.getLongestMessage();

        assertEquals("This message is definitely longer", longest.getContent());
    }

    // ---------------------------------------------------------
    @Test
    public void testDeleteByHash() {
        Message m = new Message(0, "+2783", "+2783", "Delete me");
        manager.sendMessage(m);

        boolean deleted = manager.deleteByHash(m.getHash());

        assertTrue(deleted);
        assertEquals(0, manager.getMessages().size());
    }

    // ---------------------------------------------------------
    // EXTRA TEST 1 – No longest message if list empty
    // ---------------------------------------------------------
    @Test
    public void testGetLongestMessageEmpty() {
        manager.getMessages().clear();
        assertNull(manager.getLongestMessage());
    }

    // ---------------------------------------------------------
    // EXTRA TEST 2 – Search nonexistent ID
    // ---------------------------------------------------------
    @Test
    public void testSearchByIdNotFound() {
        manager.getMessages().clear();
        assertNull(manager.searchById("0000000000"));
    }
}