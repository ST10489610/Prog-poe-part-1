/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.chatapp;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;



/**
 *
 * @author hifi
 */
public class ChatAppGUI {
     public static void main(String[] args) {
       login login = new login();

        // Custom look for all pop-ups
        UIManager.put("OptionPane.background", new Color(173, 216, 230));      // light blue
        UIManager.put("Panel.background",     new Color(173, 216, 230));      // match background
        UIManager.put("OptionPane.messageForeground", Color.BLACK);           // black text
        UIManager.put("OptionPane.border", new LineBorder(new Color(0, 51, 102), 3)); // dark-blue border

        // === Registration ===
        while (true) {
            JOptionPane.showMessageDialog(
                null,
                "Welcome to the Chat App!\nLet's set up your account.",
                "Account Setup",
                JOptionPane.INFORMATION_MESSAGE
            );

            String username = JOptionPane.showInputDialog(
                null,
                "Choose a username (must include '_' and be 5 characters or fewer):",
                "Username",
                JOptionPane.QUESTION_MESSAGE
            );
   if (username == null) return;

            String password = JOptionPane.showInputDialog(
                null,
                "Create a password (8+ characters, a capital letter, a number, and a symbol):",
                "Password",
                JOptionPane.QUESTION_MESSAGE
            );
            if (password == null) return;

            String cellphone = JOptionPane.showInputDialog(
                null,
                "Enter your cellphone number (include country code, e.g. ‪+27838968976‬):",
                "Cellphone",
                JOptionPane.QUESTION_MESSAGE
            );
            if (cellphone == null) return;

            String regMessage = login.registerUser(username.trim(), password, cellphone.trim());
            JOptionPane.showMessageDialog(null, regMessage, "Registration", JOptionPane.INFORMATION_MESSAGE);

            if (regMessage.equals("Registration successful.")) {
                break; // proceed to login
            } // else loop back for another attempt
        }
  // === Login ===
        while (true) {
            JOptionPane.showMessageDialog(
                null,
                "Sign in with your new account.",
                "Login",
                JOptionPane.INFORMATION_MESSAGE
            );

            String username = JOptionPane.showInputDialog(
                null,
                "Username:",
                "Login",
                JOptionPane.QUESTION_MESSAGE
            );
            if (username == null) return;

            String password = JOptionPane.showInputDialog(
                null,
                "Password:",
                "Login",
                JOptionPane.QUESTION_MESSAGE
            );
            if (password == null) return;
    boolean ok = login.loginUser(username.trim(), password);
            String msg = login.returnLoginStatus(ok, username.trim());
            JOptionPane.showMessageDialog(null, msg, "Login Result",
                                          ok ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.ERROR_MESSAGE);

            if (ok) {
                break; // login successful
            }
            // otherwise loop again for another attempt
        }
    }
}
    
